//Demonstration of simple java program
package day1.basics;
import java.util.LinkedList ; //all subpackages

public class FirstProgram {
	public static void main(String[] args) {
		System.out.println("Hello World");
	}
}