//Program to guess a number in a given range
package day1.basics;

public class IfDemo {

	public static void main(String[] args) {

		int x = 6;
		if (x != 5) {{
			System.out.println("Value of x is not 5");
			}}

		else {
		System.out.println("Value of x is 5");
	}
}}

